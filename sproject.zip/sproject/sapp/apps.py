from django.apps import AppConfig


class SappConfig(AppConfig):
    name = 'sapp'
